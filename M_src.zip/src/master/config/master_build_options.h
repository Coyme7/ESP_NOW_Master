#pragma once

#include <Arduino.h>

// 主机同步测试模式。默认 SingleX：当前已验证旋钮控制 X，Y 坐标固定为 0。
enum MasterSyncTestMode : uint8_t {
    MASTER_MODE_SINGLE_X = 0,
    MASTER_MODE_SINGLE_Y = 1,
    MASTER_MODE_DUAL_XY = 2,
};

// 启用主机 X 旋钮真实硬件。默认开启，因为当前同步链路依赖已验证的 X 旋钮。
#ifndef MASTER_X_KNOB_HW_ENABLED
#define MASTER_X_KNOB_HW_ENABLED 1
#endif

// 启用主机 Y 旋钮真实硬件。默认关闭，避免未 bring-up 的第二旋钮影响 X 单轴同步。
#ifndef MASTER_Y_KNOB_HW_ENABLED
#define MASTER_Y_KNOB_HW_ENABLED 0
#endif

// 主机同步测试模式。SingleY 可复用当前已验证 X 旋钮，把输入写入 y_norm 进行 Y 轴 bring-up。
#ifndef MASTER_SYNC_TEST_MODE
#define MASTER_SYNC_TEST_MODE MASTER_MODE_SINGLE_X
#endif

// 主机真实力反馈输出开关。
// 默认值：0，只保留传感器读取和 0A FOC 维护，避免同步测试时引入力矩干扰。
// 用途：后续需要旋钮手感或边界力矩时显式设为 1。
// 风险：设为 1 会输出真实力矩，可能影响从机 SingleX 性能判断。
// 依赖：当前从机性能收口阶段必须保持关闭，不能把主机力反馈策略搬到从机。
#ifndef MASTER_FORCE_FEEDBACK_ENABLED
#define MASTER_FORCE_FEEDBACK_ENABLED 1
#endif

// 主机启动配置日志开关。
// 默认值：1，上电时打印模式、硬件开关、ESP-NOW 和控制周期。
// 用途：现场确认主机是否处于 SingleX、force feedback 关闭等安全默认状态。
// 风险：只在启动路径打印；关闭后不影响控制和通信。
// 依赖：不控制运行期状态任务。
#ifndef MASTER_BOOT_LOG_ENABLED
#define MASTER_BOOT_LOG_ENABLED 1
#endif

// 主机 ESP-NOW 身份日志开关。
// 默认值：跟随 MASTER_BOOT_LOG_ENABLED，上电时打印本机 STA MAC、对端 MAC 和固定信道。
// 用途：现场确认两块板是否烧录反、MAC 是否写错、主从信道是否一致。
// 风险：只在启动路径打印；关闭后不会影响 ESP-NOW 初始化和收发。
// 依赖：仅在 MASTER_ESPNOW_ENABLED=1 时有输出。
#ifndef MASTER_ESPNOW_IDENTITY_LOG_ENABLED
#define MASTER_ESPNOW_IDENTITY_LOG_ENABLED MASTER_BOOT_LOG_ENABLED
#endif

// 主机控制定时器启动日志开关。
// 默认值：跟随 MASTER_BOOT_LOG_ENABLED，成功启动时打印周期和 dispatch 模式。
// 用途：确认 200us 控制定时器是否按预期启用 ISR/task dispatch。
// 风险：只控制成功启动提示；创建失败和启动失败仍会打印错误，便于定位上电问题。
// 依赖：只影响控制任务启动阶段，不影响 5kHz 控制循环。
#ifndef MASTER_CONTROL_TIMER_LOG_ENABLED
#define MASTER_CONTROL_TIMER_LOG_ENABLED MASTER_BOOT_LOG_ENABLED
#endif

// 主机低频状态日志总开关。
// 默认值：1，创建状态打印任务。
// 用途：低频观察命令、遥测、同步误差和 fault。
// 风险：串口输出只能在 Core 0 状态任务中运行，不能进入控制热路径。
// 依赖：关闭后摘要/timing 细分开关都不会输出。
#ifndef MASTER_STATUS_LOG_ENABLED
#define MASTER_STATUS_LOG_ENABLED 1
#endif

// 主机状态任务打印周期。
// 默认值：500ms，约 2Hz；比旧 100ms/10Hz 更适合长期观察，减少 Core 0 串口格式化压力。
// 用途：统一控制主机运行期 Serial.printf 频率，不影响 ESP-NOW 命令发送周期。
// 风险：设得过小会增加串口输出和浮点格式化开销；设得过大则现场观察刷新变慢。
// 依赖：仅在 MASTER_STATUS_LOG_ENABLED=1 且状态任务创建后生效。
#ifndef MASTER_STATUS_LOOP_PERIOD_MS
#define MASTER_STATUS_LOOP_PERIOD_MS 500UL
#endif

// 主机摘要状态行开关。
// 默认值：1，输出模式、tx/ack、主机位置、pen、链路计数和 fault。
// 用途：常规主从联调时保留最短可读摘要。
// 风险：包含少量浮点格式化，频率由 MASTER_STATUS_LOOP_PERIOD_MS 控制。
// 依赖：受 MASTER_STATUS_LOG_ENABLED 总开关控制。
#ifndef MASTER_STATUS_SUMMARY_LOG_ENABLED
#define MASTER_STATUS_SUMMARY_LOG_ENABLED 1
#endif

// 主机同步误差详情行开关。
// 默认值：1，输出编码器诊断、协议归一化坐标、从机遥测位置和 XY 同步误差。
// 用途：联调 X/Y 同步时观察实际误差；性能收口时可关闭，只保留摘要行。
// 风险：包含较多浮点格式化和编码器诊断快照，开启后串口行更长。
// 依赖：受 MASTER_STATUS_LOG_ENABLED 总开关控制；不会读取电机或传感器热路径。
#ifndef MASTER_STATUS_SYNC_LOG_ENABLED
#define MASTER_STATUS_SYNC_LOG_ENABLED 1
#endif

// 主机 timing 健康行开关。
// 默认值：1，只有控制健康或 timing 诊断开启时才输出 ctrl_dt/ctrl_max/over/miss。
// 用途：定位主机控制任务是否丢周期。
// 风险：输出字段更多但仍只在状态任务中打印；关闭后不影响统计本身。
// 依赖：需要 MASTER_CONTROL_HEALTH_DIAG_ENABLED 或 MASTER_CONTROL_TIMING_DIAG_ENABLED。
#ifndef MASTER_STATUS_TIMING_LOG_ENABLED
#define MASTER_STATUS_TIMING_LOG_ENABLED 1
#endif

// 主机 timing 分段详情行开关。
// 默认值：0，避免默认串口输出过长；需要分析 control/motor/current/sensor 分段耗时时再开启。
// 用途：配合 MASTER_CONTROL_TIMING_DIAG_ENABLED=1 输出分段 last/avg/max。
// 风险：会增加状态行数量和格式化成本，不应作为日常默认日志。
// 依赖：需要 MASTER_STATUS_TIMING_LOG_ENABLED=1 且 MASTER_CONTROL_TIMING_DIAG_ENABLED=1。
#ifndef MASTER_STATUS_TIMING_DETAIL_LOG_ENABLED
#define MASTER_STATUS_TIMING_DETAIL_LOG_ENABLED 0
#endif

// 主机 timing 诊断总开关。默认关闭；开启后增加 micros() 采样开销，只用于性能定位。
#ifndef MASTER_TIMING_DIAG_ENABLED
#define MASTER_TIMING_DIAG_ENABLED 1
#endif

static_assert(MASTER_STATUS_LOOP_PERIOD_MS > 0,
              "MASTER_STATUS_LOOP_PERIOD_MS must be greater than 0");

// BLE 控制器模式预留开关。当前阶段不做 BLE，默认关闭且不得影响 ESP-NOW 同步链路。
#ifndef MASTER_BLE_MODE_ENABLED
#define MASTER_BLE_MODE_ENABLED 0
#endif

static_assert(MASTER_SYNC_TEST_MODE == MASTER_MODE_SINGLE_X ||
                  MASTER_SYNC_TEST_MODE == MASTER_MODE_SINGLE_Y ||
                  MASTER_SYNC_TEST_MODE == MASTER_MODE_DUAL_XY,
              "invalid MASTER_SYNC_TEST_MODE");

inline const char *masterSyncTestModeName() {
    switch (MASTER_SYNC_TEST_MODE) {
        case MASTER_MODE_SINGLE_X:
            return "SingleX";
        case MASTER_MODE_SINGLE_Y:
            return "SingleY";
        case MASTER_MODE_DUAL_XY:
            return "DualXY";
        default:
            return "Unknown";
    }
}

// 上板调试快速调参区。
// 所有宏都用 #ifndef 包裹，允许 platformio.ini/build_flags 临时覆盖。

// 真实主机电机硬件总开关。
// 0：只运行算法、通信、状态机，不初始化真实驱动和 SimpleFOC 输出。
// 1：初始化电机驱动、电流采样、编码器和 SimpleFOC，允许真实力反馈输出。
// 安全建议：第一次上电或改硬件接线后，先设为 0 验证通信和状态输出。
#ifndef MASTER_MOTOR_HW_ENABLED
#define MASTER_MOTOR_HW_ENABLED MASTER_X_KNOB_HW_ENABLED
#endif

// 力矩控制模式选择。
// 1：使用 foc_current 电流闭环，目标量是真实 q 轴电流，适合力反馈旋钮。
// 0：使用 voltage 电压力矩模式，目标量近似为输出电压，适合低风险 bring-up。
// 当前项目主机力觉反馈以电流环为目标，因此正常联调应保持 1。
#ifndef MASTER_USE_CURRENT_SENSE
#define MASTER_USE_CURRENT_SENSE 1
#endif

// 0A 冒烟测试开关。
// 1：无论虚拟墙、阻尼、固定电流测试如何计算，真实电机目标电流都固定为 0A。
// 用途：确认电流采样、电流环方向、iq/id 偏置、vq/vd 是否稳定，不让旋钮产生主动力矩。
#ifndef MASTER_CURRENT_ZERO_CURRENT_SMOKE_TEST
#define MASTER_CURRENT_ZERO_CURRENT_SMOKE_TEST 0
#endif

// 0A 烟测时的电流控制类型。
// 1：使用 dc_current，主要用于排查电流采样方向和 SimpleFOC 电流通道。
// 0：使用 foc_current，和正常力反馈路径一致。
// 一般不改；只有确认 foc_current 路径异常时才临时切到 dc_current 对照。
#ifndef MASTER_CURRENT_ZERO_SMOKE_USE_DC_CURRENT
#define MASTER_CURRENT_ZERO_SMOKE_USE_DC_CURRENT 0
#endif

// 电流采样诊断模式。
// 1：只做短促 U/V/W 注入采样，打印 ia/ib/相电流响应，不进入正常 FOC 运行态。
// 用途：确认 shunt、gain、ADC 引脚、采样符号是否正确。
// 注意：该模式是启动诊断路径，不能和正常力反馈联调同时使用。
#ifndef MASTER_CURRENT_SENSE_DIAG_ONLY
#define MASTER_CURRENT_SENSE_DIAG_ONLY 0
#endif

// 控制环分段耗时诊断开关。
// 1：记录热路径中编码器读取、电流采样、loopFOC、总控制步等耗时，并低频输出。
// 用途：验证 200us/5kHz 控制周期是否有余量。
// 注意：诊断会调用 micros()，会有少量额外开销；正式手感测试可关闭。
#ifndef MASTER_CONTROL_TIMING_DIAG_ENABLED
#define MASTER_CONTROL_TIMING_DIAG_ENABLED MASTER_TIMING_DIAG_ENABLED
#endif

// 轻量级控制环健康状态输出开关。
// 默认跟随完整时序诊断开关，只输出 ctrl_dt / ctrl_max / overC / miss 等简短字段。
// 用途：正常联调时用较短状态行观察是否漏周期、是否超时。
#ifndef MASTER_CONTROL_HEALTH_DIAG_ENABLED
#define MASTER_CONTROL_HEALTH_DIAG_ENABLED MASTER_CONTROL_TIMING_DIAG_ENABLED
#endif

// 控制环状态发布分频。
// 控制任务仍按 MASTER_CONTROL_LOOP_PERIOD_US 高频运行；这里只降低 sysData 调试字段刷新频率。
// 例如 10 表示控制 5kHz 时，调试状态约 500Hz 更新，减少跨任务共享数据写入压力。
#ifndef MASTER_CONTROL_STATUS_PUBLISH_DIV
#define MASTER_CONTROL_STATUS_PUBLISH_DIV 10
#endif

// 强力矩触觉调试档开关。
// 1：使用强墙感/强阻尼/较高电流上限的调试参数。
// 0：使用保守默认参数，适合低风险首次上电。
// 注意：名字里有 TEST，但当前阶段它相当于“强力矩配置档位”。
#ifndef MASTER_STRONG_TORQUE_TEST_ENABLED
#define MASTER_STRONG_TORQUE_TEST_ENABLED 1
#endif

// 固定小电流测试开关。
// 1：绕过虚拟墙、中心阻尼、越界逻辑，直接输出 MASTER_FIXED_CURRENT_TEST_A。
// 用途：确认电流方向、力矩方向和电机响应，不用于正常力反馈手感测试。
#ifndef MASTER_FIXED_CURRENT_TEST_ENABLED
#define MASTER_FIXED_CURRENT_TEST_ENABLED 0
#endif

// 主机 ESP-NOW 通信开关。
// 1：初始化 Wi-Fi/ESP-NOW，创建通信任务，发送主机命令并接收从机遥测。
// 0：单机排查电流环、编码器或力反馈时关闭无线，减少 Core 0 干扰和日志噪声。
#ifndef MASTER_ESPNOW_ENABLED
#define MASTER_ESPNOW_ENABLED 1
#endif

// 强制落笔测试开关。
// 1：未接真实主机按钮/紫光灯控制输入时，固定发送 pen_down=1，便于验证主从通信链路。
// 0：后续接入真实按钮后，改回由按钮状态控制 pen_down。
#ifndef MASTER_FORCE_PEN_DOWN_FOR_TEST
#define MASTER_FORCE_PEN_DOWN_FOR_TEST 0
#endif

static_assert(!(MASTER_FORCE_PEN_DOWN_FOR_TEST && MASTER_BLE_MODE_ENABLED),
              "forced pen test and BLE mode should not be enabled together");

// SimpleFOC 启动诊断日志开关。
// 1：输出 init/initFOC 阶段日志，便于查看驱动、电流采样、编码器初始化情况。
// 注意：只允许出现在启动路径，不能进入高频控制热路径。
#ifndef MASTER_SIMPLEFOC_DEBUG_ENABLED
#define MASTER_SIMPLEFOC_DEBUG_ENABLED 1
#endif

// initFOC 前开环相位扫描诊断开关。
// 1：用短时间低电压扫相，观察电机是否跟随、编码器角度是否变化。
// 用途：区分“驱动没有带动电机”和“编码器没有读到变化”。
#ifndef MASTER_MOTOR_PHASE_PROBE_ENABLED
#define MASTER_MOTOR_PHASE_PROBE_ENABLED 0
#endif

// 临时正交编码器演示输入开关。
// 1：使用两个 GPIO 的中断计数代替 MT6701，用于早期无磁编码器时演示输入。
// 当前主机已使用 MT6701，正常应保持 0。
#ifndef MASTER_DEMO_QUADRATURE_ENABLED
#define MASTER_DEMO_QUADRATURE_ENABLED 0
#endif
